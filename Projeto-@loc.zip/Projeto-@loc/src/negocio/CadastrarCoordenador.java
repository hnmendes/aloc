package negocio;

public class CadastrarCoordenador {

}
