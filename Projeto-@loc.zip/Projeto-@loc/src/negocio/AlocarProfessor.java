package negocio;

public class AlocarProfessor {

}
